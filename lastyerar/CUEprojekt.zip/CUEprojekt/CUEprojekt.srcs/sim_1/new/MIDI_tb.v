`timescale 1ns / 1ps

module MIDI_tb( );

reg clk;
reg [11:0] note;
wire out;
wire [23:0] dout;

MIDI uut ( .clk(clk), .note(note), .out(out), .dout(dout));

reg [23:0] chk [11:0];

initial begin
    clk=0;
    forever #5 clk = ~clk; 
end
integer i;
integer file;
initial begin
    $monitor("%h",dout);
    note = 12'b00000000000;
    #50
    //align   BA9876543210
    note = 12'b00010010001;
    #200
    note = 12'b00000000000;
    #800
    //align   BA9876543210
    note = 12'b10010000100;
    #200
    note = 12'b00000000000;
    #2750
    $readmemh("rawmidi.txt", chk);
    for (i = 0; i < 12; i = i + 1)
    begin
        $display("%d %h",i,chk[i]);
    end
    $finish;   

end

endmodule
