@echo off
set xv_path=D:\\Xilinx\\Vivado\\2017.1\\bin
call %xv_path%/xsim MIDI_tb_behav -key {Behavioral:sim_1:Functional:MIDI_tb} -tclbatch MIDI_tb.tcl -view D:/Games/VIVADO_PROJECTS/CUEprojekt/MIDI_tb_behav_01.wcfg -log simulate.log
if "%errorlevel%"=="0" goto SUCCESS
if "%errorlevel%"=="1" goto END
:END
exit 1
:SUCCESS
exit 0
